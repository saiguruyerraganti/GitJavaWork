import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
public static void main(String[] args) throws NumberFormatException, ParseException {
    	
		Scanner sc= new Scanner(System.in);//Initializing scanner
		List<TicketBooking> li= new ArrayList<TicketBooking>();//Creating arraylist to store values
		System.out.println("Enter the number of bookings:");//Get number of bookings from user
		int n= Integer.parseInt(sc.nextLine());
		
		for(int i=0;i<n;i++)//Get booki details
		{
			System.out.println("Enter the details of booking "+(i+1));
			String data= sc.nextLine();
			String a[]= data.split(",");//Split the string 
			TicketBooking tb= new TicketBooking(a[0],(new SimpleDateFormat("dd-MM-yyyy").parse(a[1])),a[2],Double.parseDouble(a[3]));
			li.add(tb);//Creating object for Ticketbooking class and adding it to arrayList
		}
		System.out.println("Sorted Order:");
		Collections.sort(li,new PriceAndBookingTimeComparator());//Sorting using price and Booking time comparator
		System.out.printf("%-15s%-15s%-15s%-15s\n","Event name","Booking Time","Seat number","Price");
		for (TicketBooking ticketBooking : li) {//Printing sorted list
			System.out.println(ticketBooking);
		}

	}
}
=========================
import java.text.SimpleDateFormat;
import java.util.Date;

public class TicketBooking {

    private String stageEventShow;//declaring variables
	private Date bookingTime;
	private String seatNumber;
	private double price;
	
	public TicketBooking() {//Default constructor
		super();
	}

	public TicketBooking(String stageEventShow, Date bookingTime, String seatNumber, double price) {//Parameterized constructor
		super();
		this.stageEventShow = stageEventShow;
		this.bookingTime = bookingTime;
		this.seatNumber = seatNumber;
		this.price = price;
	}

	public String getStageEventShow() {//Getter and setters for variables in class
		return stageEventShow;
	}

	public void setStageEventShow(String stageEventShow) {
		this.stageEventShow = stageEventShow;
	}

	public Date getBookingTime() {
		return bookingTime;
	}

	public void setBookingTime(Date bookingTime) {
		this.bookingTime = bookingTime;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String toString()//toString method to print data
	{
		String st= new SimpleDateFormat("dd-MM-yyyy").format(bookingTime);
		System.out.printf("%-15s%-15s%-15s%-15s",stageEventShow,st,seatNumber,price);
		return "";
	}
	
	
}
=======================
import java.util.Comparator;

public class PriceAndBookingTimeComparator implements Comparator<TicketBooking> {//Price and booking time comparator implementing comparator

    @Override
	public int compare(TicketBooking booking1, TicketBooking booking2) {//Comparing two objects
		if(booking1.getPrice()>booking2.getPrice())//If price of object1 is more than object to then return 1
		 return 1;
		else if(booking1.getPrice()<booking2.getPrice())//If price of object1 is less than object to then return 1
	     return -1;
		else
		return (booking1.getBookingTime().compareTo(booking2.getBookingTime()));//if price are equal, then compare booking time
			
	}

	
}

