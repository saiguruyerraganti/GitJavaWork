import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
import java.util.List;

public class Main {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("input.csv"));
		ItemBO bo= new ItemBO();//Create object for ItemBO
    	List<Item> li= bo.readFile(br);//Call method readFile to store data in list
		
		System.out.format("%-20s %-20s %-20s %s\n", "Item Number","Vendor Name","Item Type","Cost");//Print data
		for (Item item : li) {
			System.out.format("%-20s %-20s %-20s %s\n",item.getItem_number(),item.getItem_vendor(),item.getItem_type().getItemTypeName(),item.getItem_type().getCost());
		}
		
	}

}
=========================
public class ItemType{

    private String itemTypeName;        //Declaring private variables
	private double cost;
	
	public ItemType() {                //Default constructor
		super();
	}

	public ItemType(String itemTypeName, double cost) {
		super();
		this.itemTypeName = itemTypeName;
		this.cost = cost;
	}

	public String getItemTypeName() {             //Getters and setters for variables
		return itemTypeName;
	}

	public void setItemTypeName(String itemTypeName) {
		this.itemTypeName = itemTypeName;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}	
	
}
=======================
public class Item {
    
	private int item_number;                //Declaring variables
	private String item_vendor;
	private ItemType item_type;
	
	public Item() {                     //Default constructor
		super();
	}

	public Item(int item_number, String item_vendor, ItemType item_type) {           //Parameterized constructor
		super();
		this.item_number = item_number;
		this.item_vendor = item_vendor;
		this.item_type = item_type;
	}

	public int getItem_number() {                                    //Getters and setters for variables
		return item_number;
	}

	public void setItem_number(int item_number) {
		this.item_number = item_number;
	}

	public String getItem_vendor() {
		return item_vendor;
	}

	public void setItem_vendor(String item_vendor) {
		this.item_vendor = item_vendor;
	}

	public ItemType getItem_type() {
		return item_type;
	}

	public void setItem_type(ItemType item_type) {
		this.item_type = item_type;
	}	

}
======================
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ItemBO {
    
	List<Item> li= new ArrayList<Item>();
	
	 public List<Item> readFile(BufferedReader br)
	 {
		 String strcurrentLine;
		 try {//try method start
			while((strcurrentLine=br.readLine())!=null)//if data is not null in the file
				{
					String details[]= strcurrentLine.split(",");//Split details from file
					ItemType it= new ItemType(details[2],Double.parseDouble(details[3]));	//Create object for ItemType class
					Item i= new Item(Integer.parseInt(details[0]),details[1],it);//Create object for item class
					//ItemType it= new ItemType(itemTypeName, cost)		
					li.add(i);//add it to list
				}
		} catch (NumberFormatException | IOException e) {//Catch method starts
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return li;//Return list
		 
	 }

}
==================================
Input.cvs


1,Martin,Leather,2000
15,Louis,Mud,1300.50
23,Jaques kallis,Electronics,100
38,McCullum,Wood,3000.4


