import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
		
		FileReader input= new FileReader("input.txt");
		BufferedReader br= new BufferedReader(input);
		List<ItemType> li=null;
		List<ItemType> li2=null;
		
		ItemTypeBO ibo= new ItemTypeBO();//Creating object for ItemTypeBO class
		
		try {
			li=ibo.readFromFile(br);//Call method readfromFile to get data from file to list
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		int count=0;//To get count of entries whose deposit is more than 2000
		for (ItemType string : li) {
			if(string.getDeposit()>2000)//Check deposit
			{
				count++;//If deposit is more than 2000, increment the count
			}
		}
		
		if(count==0)//If count is zero
		{
			System.out.println("No item type has deposit more than 2000");//Print no item type
		}
		else
		{
			li2=ibo.depositList(li);
			System.out.format("%-15s %-15s %s\n","Item type","Deposit","Cost per day");//Else seperate list of deposites
			ibo.display(li2);//Display seperated list
		}
		
		

	}

}

===============================
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class ItemTypeBO {
    
public List<ItemType> readFromFile(BufferedReader br) throws IOException//readFromFile method
{
	List<ItemType> li= new ArrayList<ItemType>();//Initialize arraylist 
	String line;//Initialize line
	while((line=br.readLine())!=null){//If file not reached to end
		
		String details[] = new String[3];//Initialize string array to store data
		StringTokenizer st=new StringTokenizer(line);//Initialize string tokenizer to remove space
		int i=0;  
		while (st.hasMoreElements()) {
			details[i]=st.nextToken();//Copy data int array
			i++;
		}
		
		ItemType it= new ItemType(details[0],Double.parseDouble(details[1]),Double.parseDouble(details[2]));//Create object for itemtype class and load data into constructor
		li.add(it);//Add it to list
	}
	return li;//Return list
	
}

public List<ItemType> depositList(List<ItemType> list)//Deposit list method start
{
	List<ItemType> li= new ArrayList<ItemType>();//Initialize arraylist
	for (ItemType itemType : list) {//For elements in list
		if(itemType.getDeposit()>2000)//If deposit is greater than 2000
		{
			ItemType it= new ItemType(itemType.getName(),itemType.getDeposit(),itemType.getCostPerDay());//Create object for itemtype class and load data into constructor
			li.add(it);//Add it to list
		}
	}
	return li;//Return list
}

public void display(List<ItemType> list)//Display method start
{
	for (ItemType itemType : list) {//Print data in list
		System.out.format("%-15s %-15s %s\n",itemType.getName(),itemType.getDeposit(),itemType.getCostPerDay());
	}
	
}


}
====================================
public class ItemType {
    
	private String name;//Declaring variables
	private double deposit;
	private double costPerDay;
	
	public ItemType() {//Default constructor
		super();
	}

	public ItemType(String name, double deposit, double costPerDay) {//Parameterized constructor
		super();
		this.name = name;
		this.deposit = deposit;
		this.costPerDay = costPerDay;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public double getCostPerDay() {
		return costPerDay;
	}

	public void setCostPerDay(double costPerDay) {
		this.costPerDay = costPerDay;
	}
}

========================
Input

Electronics    1000   200  
Chemicals      500    100  
Electrical     2100   500  
Construction   5000   1000 
